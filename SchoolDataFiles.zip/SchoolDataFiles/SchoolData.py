import pandas as pd

# Enrollment dataset cleaning and calculation
enrollmentFilePath = "Enrollment_by_Grade_2022-23.csv"
dfEnrollment = pd.read_csv(enrollmentFilePath)
dfEnrollment = dfEnrollment[dfEnrollment["ENROLLMENT_COUNT"] != "TFS"]
dfEnrollment["ENROLLMENT_COUNT"] = pd.to_numeric(dfEnrollment["ENROLLMENT_COUNT"], errors="coerce")
filteredEnrollmentDf = dfEnrollment[dfEnrollment["GRADES_SERVED_DESC"] == "09,10,11,12"]
averageEnrollment = filteredEnrollmentDf.groupby("INSTN_NUMBER")["ENROLLMENT_COUNT"].mean().reset_index()

# SAT dataset cleaning
satFilePath = "SAT_HIGHEST_2022.csv"
satDf = pd.read_csv(satFilePath, dtype={"INSTN_NUMBER": str})
satFilteredDf = satDf[satDf["TEST_CMPNT_TYP_CD"] == "Combined Test Score"]
satFilteredDf = satFilteredDf.rename(columns={"INSTN_AVG_SCORE_VAL": "SAT_AVG_SCORE"})

# ACT dataset cleaning
actFilePath = "ACT_HIGHEST_2022.csv"
actDf = pd.read_csv(actFilePath, dtype={"INSTN_NUMBER": str})
actFilteredDf = actDf[actDf["TEST_CMPNT_TYP_CD"] == "Composite"]
actFilteredDf = actFilteredDf.rename(columns={"INSTN_AVG_SCORE_VAL": "ACT_AVG_SCORE"})

# HOPE dataset cleaning
otherFilePath = "HOPE_ELIGIBLE_2022-23.csv"
dfHope = pd.read_csv(otherFilePath, dtype={"INSTN_NUMBER": str}).query("INSTN_NUMBER != 'ALL'")

# Graduation Rate Cleaning
graduationRatePath = "Graduation_Rate_2022-23.csv"
graduationDf = pd.read_csv(graduationRatePath)
graduationDf = graduationDf[graduationDf["INSTN_NUMBER"] != "All"]
graduationDf["INSTN_NUMBER"] = graduationDf["INSTN_NUMBER"].astype(str)
graduationDf["instnNumberIsNumeric"] = pd.to_numeric(graduationDf["INSTN_NUMBER"], errors="coerce").notnull()
graduationDf = graduationDf[graduationDf["instnNumberIsNumeric"]]
graduationDf = graduationDf.drop(columns=["instnNumberIsNumeric"])

# Combine
combinedDf = pd.merge(satFilteredDf, actFilteredDf, on="INSTN_NUMBER", how="outer", suffixes=("_SAT", "_ACT"))
combinedDf = pd.merge(combinedDf, dfHope, on="INSTN_NUMBER", how="outer")
combinedDf = pd.merge(combinedDf, averageEnrollment, on="INSTN_NUMBER", how="outer")
combinedDf = pd.merge(combinedDf, graduationDf, on="INSTN_NUMBER", how="outer")

# Only keep relevant columns
finalColumns = [
    "INSTN_NUMBER", "INSTN_NAME_SAT", "SCHOOL_DSTRCT_NM_SAT", "SCHOOL_DISTRCT_CD", 
    "SAT_AVG_SCORE", "ACT_AVG_SCORE", "HOPE_ELIGIBLE_PCT", "ENROLLMENT_COUNT", "PROGRAM_PERCENT"
]

finalDf = combinedDf[finalColumns]

columns_to_clean = ["SAT_AVG_SCORE", "ACT_AVG_SCORE", "HOPE_ELIGIBLE_PCT", "ENROLLMENT_COUNT", "PROGRAM_PERCENT"]

for column in columns_to_clean:
    finalDf[column] = pd.to_numeric(finalDf[column], errors='coerce')


outputFilePath = "final_combined_data.csv"
finalDf.to_csv(outputFilePath, index=False)


